﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;

namespace CyberPredictorAPI.Models
{
    public class TeamScaleModel
    {
        /*New Customer Creation & Get project list*/
        public string UserLoginId { get; set; }
      
        public Boolean EmailFlag { get; set; }
       


        public string ProjectId { get; set; }
        public DateTime ScanDateTime { get; set; }
        public string ProjectName { get; set; }
        public string ProjDescription { get; set; }

        public string Code_Anomalies { get; set; }
        public string Code_Duplication { get; set; }
        public string Documentation { get; set; }
        public string Formatting { get; set; }
        public string Naming { get; set; }
        public string Structure { get; set; }
        public string Status { get; set; }
        public string Message { get; set; }
    }
}