﻿using CyberPredictorAPI.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml;
using System.Text.RegularExpressions;
namespace ConsoleApplicationTest
{
    class Program
    {
        public static void Main(string[] args)
        {

          //  string APPDynamicURL = "http://172.16.1.3:8080/create-project";
            //  string APPDynamicAut = Program.getUserport("AppDynamic_Token");

            //string Live = "{\"timeRange\":\"last_3_hours.BEFORE_NOW.-1.-1.180\",\"metricNames\":[\"Hardware Resources|CPU|%Busy\",\"Hardware Resources|CPU|%Stolen\",\"Hardware Resources|CPU|System\"],\"rollups\":[1440,1],\"ids\":[13777],\"baselineId\":null}";     
          //  string path = "D:/Backup/win7sp1/Documents/Visual Studio 2012/CyberPredictorFinal/CyberPredictorAPI V4.0/CyberPredictorAPI V4.0";
           // string Live = "{\"name\":\"ss\",\"id\":\"ss\",\"alias\":null,\"description\":\"\",\"profile\":\"C# (default)\",\"connectors\":[{\"options\":{\"Input directory\":\"" + path + "\",\"Repository identifier\":\"repository1\",\"Included file names\":\" **.cs, **.architecture\",\"Excluded file names\":\"**.designer.cs, **.g.cs, **/AssemblyInfo.cs\",\"Default branch name\":\"default\",\"Enable branch analysis\":false,\"Included branches\":\".*\",\"Excluded branches\":\"\",\"Start revision\":\"2018-11-27\",\"Content exclude\":\"\",\"Polling interval\":\"60\",\"Test-code path pattern\":\"\",\"Test-code path exclude pattern\":\"\",\"Prepend repository identifier\":false,\"End revision\":\"\",\"Text filter\":\"\",\"Language mapping\":\"\",\"Analysis report mapping\":\"\",\"Partition Pattern\":\"\",\"File-size exclude\":\"1MB\",\"Source library connector\":false,\"Run to exhaustion\":false,\"Preserve empty commits\":false,\"Delta size\":\"500\",\"Path prefix transformation\":\"\",\"Path transformation\":\"\",\"Encoding\":\"\",\"Author transformation\":\"\",\"Branch transformation\":\"\"},\"type\":\"File System\"}]}";
            ///
            //string APPDynamicAut = "admin:rbYoj5ZKjdEywV8FOS815a7qXdeIolrL";
            Program _program = new Program();

          //  string RepModule = _program.perfixitExecuteResultCollect_Appdynamic(APPDynamicURL, Live, APPDynamicAut);

            List<TeamScaleModel> ScanFeatureModel = new List<TeamScaleModel>();

            ////WebRequest req = WebRequest.Create(@"http://172.16.1.72:8080/api/projects");
            WebRequest req = WebRequest.Create(@"http://172.16.1.54:8080/api/projects");
            req.Method = "GET";
            req.Headers["Authorization"] = "Basic " + Convert.ToBase64String(Encoding.Default.GetBytes("admin:gXTNrZjUGpLVaoDeJ0ahWEMVuY7Z8qdE"));
            //req.Credentials = new NetworkCredential("username", "password");
            HttpWebResponse resp_project_list = req.GetResponse() as HttpWebResponse;
            using (Stream stream = resp_project_list.GetResponseStream())
            {
                StreamReader reader = new StreamReader(stream, Encoding.UTF8);
                String responseString = reader.ReadToEnd();
                Newtonsoft.Json.Linq.JObject[] myDetails = JsonConvert.DeserializeObject<Newtonsoft.Json.Linq.JObject[]>(responseString);
                foreach (var item in myDetails)
                {
                    TeamScaleModel Teamscalerepostry = new TeamScaleModel();
                    Teamscalerepostry.ProjectId = item["id"].ToString();
                    Teamscalerepostry.ProjectName = item["name"].ToString();
                    //Teamscalerepostry.ProjDescription = item["description"].ToString();
                    Teamscalerepostry.ProjDescription = "---";
                    Teamscalerepostry.ScanDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0).AddSeconds(Math.Round(double.Parse(item["creationTimestamp"].ToString()) / 1000d)).ToLocalTime();
                    string url = string.Format("http://172.16.1.54:8080/p/{0}/abap-findings/?all=true", Teamscalerepostry.ProjectId);
                    WebRequest req_finding = WebRequest.Create(url);
                    req_finding.Method = "GET";
                    req_finding.Headers["Authorization"] = "Basic " + Convert.ToBase64String(Encoding.Default.GetBytes("admin:gXTNrZjUGpLVaoDeJ0ahWEMVuY7Z8qdE"));
                    //req.Credentials = new NetworkCredential("username", "password");
                    HttpWebResponse resp_finding_id = req_finding.GetResponse() as HttpWebResponse;

                    using (Stream stream1 = resp_finding_id.GetResponseStream())
                    {
                        StreamReader reader1 = new StreamReader(stream1, Encoding.UTF8);
                        String responseString1 = reader1.ReadToEnd();
                        XDocument doc = XDocument.Parse(responseString1);
                        Teamscalerepostry.Code_Anomalies = doc.Descendants("org.conqat.engine.index.shared.TrackedFinding").Where(x => x.Descendants("categoryName").ElementAt(0).Value == "Code Anomalies").Count().ToString();
                        Teamscalerepostry.Code_Duplication = doc.Descendants("org.conqat.engine.index.shared.TrackedFinding").Where(x => x.Descendants("categoryName").ElementAt(0).Value == "Code Duplication").Count().ToString();
                        Teamscalerepostry.Documentation = doc.Descendants("org.conqat.engine.index.shared.TrackedFinding").Where(x => x.Descendants("categoryName").ElementAt(0).Value == "Documentation").Count().ToString();
                        Teamscalerepostry.Formatting = doc.Descendants("org.conqat.engine.index.shared.TrackedFinding").Where(x => x.Descendants("categoryName").ElementAt(0).Value == "Formatting").Count().ToString();
                        Teamscalerepostry.Naming = doc.Descendants("org.conqat.engine.index.shared.TrackedFinding").Where(x => x.Descendants("categoryName").ElementAt(0).Value == "Naming").Count().ToString();
                        Teamscalerepostry.Structure = doc.Descendants("org.conqat.engine.index.shared.TrackedFinding").Where(x => x.Descendants("categoryName").ElementAt(0).Value == "Structure").Count().ToString();





                        // var status = doc.Descendants("uniformPath").Count().ToString();
                        var ss = doc.Descendants("message").Count().ToString();
                        // var ssss = doc.Descendants("categoryName").Count().ToString();

                        //   var sed = doc.Descendants("groupName").Count().ToString();



                        string str = "";
                        DataTable dt = new DataTable();
                        dt.Columns.Add("Location", typeof(string));
                        dt.Columns.Add("Message", typeof(string));
                        int intID = int.Parse(ss.ToString());

                        for (int i = 0; i < intID; i++)
                        {
                            DataRow dr = dt.NewRow();

                            dt.Rows.Add(dr);
                            // dr["Location"] = doc.Descendants("uniformPath").ElementAt(i).ToString();
                            //dr["Message"] = doc.Descendants("message").ElementAt(i).ToString();
                            /// Teamscalerepostry.Message = doc.Descendants("uniformPath").ElementAt(i).ToString();
                            // lstnew.doc.Descendants("uniformPath").ElementAt(i));



                            str += doc.Descendants("message").ElementAt(i).ToString() + doc.Descendants("uniformPath").ElementAt(i).ToString() + doc.Descendants("categoryName").ElementAt(i).ToString() + doc.Descendants("groupName").ElementAt(i).ToString();
                            // dr["Message"] = str;

                        }
                        string report = Regex.Replace(str, "<message[^>]*?>", "<tr><td>");
                        string re = Regex.Replace(report, "</message[^>]*?>", "</td>");
                        string we = Regex.Replace(re, "<uniformPath[^>]*?>", "<td>");
                        string qa = Regex.Replace(we, "</uniformPath[^>]*?>", "</td>");
                        string zs = Regex.Replace(qa, "<categoryName[^>]*?>", "<td>");
                        string wd = Regex.Replace(zs, "</categoryName[^>]*?>", "</td>");
                        string qaa = Regex.Replace(wd, "<groupName[^>]*?>", "<td>");
                        string wdd = Regex.Replace(qaa, "</groupName[^>]*?>", "</td></tr>");
                        string final = Regex.Replace(wdd, "'[^>]*?", " ");
                        //    string ff = Regex.Replace(qaa, "</groupName[^>]*?>", "</td></tr>");
                    }
                    ScanFeatureModel.Add(Teamscalerepostry);
                }

            }
       }




        public string perfixitExecuteResultCollect_Appdynamic(string APPDynamicURL, string Live, string APPDynamicAut)
        {

            String Result = "";
            try
            {
                String JSONContentType = "application/json";
                String JSONmethod = "PUT";
                String JSONRequest = Live;

                Uri address = new Uri(APPDynamicURL);
                HttpWebRequest httpWebRequest = WebRequest.Create(address) as HttpWebRequest;
                httpWebRequest.KeepAlive = false;
                string sb = JSONRequest;
                httpWebRequest.Method = JSONmethod;
                httpWebRequest.PreAuthenticate = true;
                httpWebRequest.Headers.Add("Authorization", string.Format("Basic " + Convert.ToBase64String(Encoding.Default.GetBytes(APPDynamicAut))));
                httpWebRequest.ContentType = JSONContentType;
                httpWebRequest.Timeout = 25000;// 86400000;//30,000,000 - 8+hrs//4,200,000 - 1+hrs//86,400,000 - 24+hrs
                Byte[] bt = Encoding.UTF8.GetBytes(Live);
                Stream st = httpWebRequest.GetRequestStream();
                st.Write(bt, 0, bt.Length);
                st.Close();

                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    Result = streamReader.ReadToEnd();
                }
            }
            catch (Exception e1)
            {
                Console.WriteLine(e1);
                Result = e1.Message;


            }

            return Result;
        }

    }

}
